export JAVA_OPTS= "-Xms128m -Xmx1024m"
